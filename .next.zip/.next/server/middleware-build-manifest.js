globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/270ec8cceb106764.js",
      "static/chunks/turbopack-58489db20f6e5922.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/270ec8cceb106764.js",
      "static/chunks/turbopack-3aad943e8f1a92c6.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/3eba6931cad880e3.js",
    "static/chunks/47f477e3d2ef265b.js",
    "static/chunks/cfbd2f33f902f4e8.js",
    "static/chunks/27d5ae5fcce60ae0.js",
    "static/chunks/turbopack-0e3e89950b2e6c88.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];